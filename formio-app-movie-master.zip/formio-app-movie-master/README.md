Example application using Form.io
---------------------------------
This is an example project that integrates into Form.io.

Installation
--------------
You can easily get this application running by typing the following in your command line.

```
npm install -g formio-cli
formio bootstrap formio/formio-app-movie
```

This will create a project for you on Form.io as well as configure this application to use your sandboxed project. Feel free to fork and modify as you like.

