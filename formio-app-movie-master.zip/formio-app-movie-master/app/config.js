angular.module('movieappApp').constant('AppConfig', {
  appUrl: 'https://movieapp.form.io',
  apiUrl: 'https://api.form.io'
});
