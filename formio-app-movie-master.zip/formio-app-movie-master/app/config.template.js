angular.module('movieappApp').constant('AppConfig', {
  appUrl: 'https://{{ path }}.form.io',
  apiUrl: 'https://api.form.io'
});
